
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.onthattilepart1;

/**
 * PROG5121 POE Part 1
 * @author Onthatile Kopang
 * Reference for regex: StackOverflow SA cellphone regex - https://stackoverflow.com/questions/17018828/how-to-validate-south-african-phone-number
 */
public class Login {
    // Stored details
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellNumber;

    public Login(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Mthods to be called when registering

    // method for Username
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Password complexity method
    public boolean checkPasswordComplexity(String password) {
        if (password.length() < 8) {
            return false;
        }
        boolean hasCapital = !password.equals(password.toLowerCase());
        boolean hasNumber = password.matches(".*[0-9].*");
        boolean hasSpecial = password.matches(".*[!@#$%^&*()_+\\-={}\\[\\]|;:'\"<>,.?/`~].*");
        return hasCapital && hasNumber && hasSpecial;
    }

    // Cell phone number method
    public boolean checkCellPhoneNumber(String cellNumber) {
        // Must be +27 followed by 9 digits = total 12 e.g. +27838968976
        return cellNumber.matches("^\\+27\\d{9}$");
    }

    // Register User 
    public String registerUser(String username, String password, String cellNumber) {
        
         
        if (!checkUserName(username)) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
 
        if (!checkCellPhoneNumber(cellNumber)) {
            return "Cell phone number is incorrectly formatted or does not contain an international code";
        }
 
        {
            return "Welcome"+ firstName +""+ lastName+"it is great to see you again";
        }
           
    }

    // Login to  verifes details
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        if (this.username == null || this.password == null) {
            return false;
        }
        return this.username.equals(enteredUsername) && this.password.equals(enteredPassword);
    }

    // 6. Return Login Status 
    public String returnLoginStatus(String enteredUsername, String enteredPassword) {
        if (loginUser(enteredUsername, enteredPassword)) {
            return "Welcome " + firstName + " " + lastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Getters for testing
    public String getUsername() { return username; }
}
    
    

