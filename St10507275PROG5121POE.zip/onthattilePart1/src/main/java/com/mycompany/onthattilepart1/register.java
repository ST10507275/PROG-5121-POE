 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.onthattilepart1;
/**
 *
 * @author Onthatile Kopang
 */
import java.util.Scanner;
public class register {
 public static void main(String[] args) {
         Scanner MyInput = new Scanner(System.in);

        System.out.println("=== REGISTRATION ===");
        System.out.print("Enter First Name: ");
        String firstName = MyInput.nextLine();
        System.out.print("Enter Last Name: ");
        String lastName = MyInput.nextLine();
        System.out.print("Enter Username (must contain an underscore and 5 or less characters): ");
        String username = MyInput.nextLine();
        System.out.print("Enter Password (8 chars, Capital, Number, Special): ");
        String password = MyInput.nextLine();
        System.out.print("Enter SA Cell Number (containing a  +27: ");
        String cellNumber = MyInput.nextLine();

        Login login = new Login(firstName, lastName);
        String registrationResult = login.registerUser(username, password, cellNumber);
        System.out.println(registrationResult);

        // Only allow login if registration succeeded
        if (registrationResult.contains("succesfully")) {
            System.out.println("\n=== LOGIN ===");
            System.out.print("Enter Username: ");
            String loginUsername = MyInput.nextLine();
            System.out.print("Enter Password: ");
            String loginPassword = MyInput.nextLine();

            System.out.println(login.returnLoginStatus(loginUsername, loginPassword));
        }
        
    }
}
