/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.onthattilepart2;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Quickchat {
    public static void main(String[] args) {
        Scanner myInput = new Scanner(System.in);
        boolean isLoggedIn = true; // from Part 1 login

        if (!isLoggedIn) {
            System.out.println("Login required.");
            return;
        }

        System.out.println("Welcome to QuickChat.");
        System.out.print("How many messages do you wish to enter? ");
        int totalToSend = myInput.nextInt();
        myInput.nextLine();

        int sentCount = 0;
        boolean running = true;
        
        while (running && sentCount < totalToSend) {
            System.out.println("\n1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Choose: ");
            int menu = myInput.nextInt();
            myInput.nextLine();

            if (menu == 1) {
                System.out.print("Enter Recipient Cell (+27718693002): ");
                String rec = myInput.nextLine();
                System.out.print("Enter Message (max 250 chars): ");
                String txt = myInput.nextLine();

                if (txt.length() > 250) {
                    System.out.println("Message exceeds 250 characters by " + (txt.length()-250) + ", please reduce size.");
                    continue;
                }

                Message msg = new Message(sentCount, rec, txt);
                
                System.out.println(msg.checkRecipientCellMessage());
                if (msg.checkRecipientCell() == 0) continue;

                System.out.println("\n--- Full Message Details ---");
                System.out.println("MessageID: " + msg.getMessageID());
                System.out.println("MessageHash: " + msg.getMessageHash());
                System.out.println("Recipient: " + msg.getRecipient());
                System.out.println("Message: " + msg.getMessageText());

                System.out.print("\n1=Send 2=Disregard 3=Store: ");
                int choice = myInput.nextInt();
                myInput.nextLine();
                System.out.println(msg.SentMessage(choice));
                
                if (choice == 1) sentCount++;
                
            } else if (menu == 2) {
                System.out.println("Coming Soon.");
            } else if (menu == 3) {
                running = false;
            }
        }
        System.out.println("\nTotal messages sent: " + Message.totalMessagesSent);
        myInput.close();
    }
}
    

