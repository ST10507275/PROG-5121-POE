/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.onthattilepart2;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
/**
 *
 * @author Student
 */
public class Message {
   private String messageID;
    private int numSent;
    private String recipient;
    private String messageText;
    private String messageHash;
    public static ArrayList<Message> sentMessages = new ArrayList<>();
    public static int totalMessagesSent = 0;

    // Normal constructor (for app)
    public Message(int numSent, String recipient, String messageText) {
        this.messageID = generateMessageID();
        this.numSent = numSent;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
    }

    // Test constructor - allows fixed ID for unit test 00:0:HITONIGHT
    public Message(String messageID, int numSent, String recipient, String messageText) {
        this.messageID = messageID;
        this.numSent = numSent;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
    }

    public String generateMessageID() {
        Random rand = new Random();
        String id = "";
        for (int i = 0; i < 10; i++) id += rand.nextInt(10);
        return id;
    }

    public boolean checkMessageID() { return messageID.length() == 10; }

    public int checkRecipientCell() {
        if (recipient != null && recipient.startsWith("+") && recipient.length() <= 13 && recipient.length() >= 10) return 1;
        return 0;
    }

    public String checkRecipientCellMessage() {
        if (checkRecipientCell() == 1) return "Cell phone number successfully captured.";
        return "Cell phone number is incorrectly formatted or does not contain an international code.";
    }

    public String createMessageHash() {
        String firstTwo = messageID.substring(0,2);
        String[] words = messageText.trim().split("\\s+");
        String first = words[0].toUpperCase().replaceAll("[^A-Z0-9]", "");
        String last = words[words.length-1].toUpperCase().replaceAll("[^A-Z0-9]", "");
        return firstTwo + ":" + numSent + ":" + first + last;
    }

    public String checkMessageLength() {
        if (messageText.length() > 250) {
            int excess = messageText.length() - 250;
            return "Message exceeds 250 characters by " + excess + ", please reduce size.";
        }
        return "Message ready to send.";
    }

    public String SentMessage(int choice) {
        if (choice == 1) { sentMessages.add(this); totalMessagesSent++; return "Message successfully sent."; }
        if (choice == 2) return "Press 0 to delete message.";
        if (choice == 3) { storeMessage(); return "Message successfully stored."; }
        return "Invalid.";
    }

    public String printMessages() { return "Messages"; }
    public int returnTotalMessagess() { return totalMessagesSent; }

    public void storeMessage() {
        try {
            FileWriter w = new FileWriter("storedMessages.json", true);
            w.write("{\"messageID\":\""+messageID+"\",\"hash\":\""+messageHash+"\",\"recipient\":\""+recipient+"\",\"message\":\""+messageText+"\"}\n");
            w.close();
        } catch (IOException e) {}
    }

    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
}