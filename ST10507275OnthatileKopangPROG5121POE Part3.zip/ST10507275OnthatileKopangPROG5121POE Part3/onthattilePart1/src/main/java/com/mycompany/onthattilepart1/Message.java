/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.onthattilepart1;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
/**
 *
 * @author Student
 */
public class Message {
   private String messageID;
    private int numSent;
    private String recipient;
    private String messageText;
    private String messageHash;
    private String sender;
    private String flag;
    public static ArrayList<Message> sentMessages = new ArrayList<>();
    // Added new arrays for part3
    public static ArrayList<Message> disregardedMessages = new ArrayList<>();
    public static ArrayList<Message> storedMessages = new ArrayList<>();
    public static ArrayList<Message> allMessages = new ArrayList<>();
    public static ArrayList<String> messageHashes = new ArrayList<>();
    public static ArrayList<String> messageIDs = new ArrayList<>();//end of new arrays
    public static int totalMessagesSent = 0;

    // Normal constructor (for app)
    public Message(int numSent, String recipient, String messageText) {
        this.messageID = generateMessageID();
        this.numSent = numSent;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
        this.sender= "0838884567";
        this.flag= "sent";
    }

    // Test constructor - allows fixed ID for unit test 00:0:HITONIGHT
    public Message(String messageID, int numSent, String recipient, String messageText) {
        this.messageID = messageID;
        this.numSent = numSent;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
        this.sender= "0838884567";
        this.flag= "sent";
    }

    public String generateMessageID() {
        Random rand = new Random();
        String id = "";
        for (int i = 0; i < 10; i++) id += rand.nextInt(10);
        return id;
    }

    public boolean checkMessageID() { return messageID.length() == 10; }

    public int checkRecipientCell() {
        if (recipient != null && recipient.startsWith("+") && recipient.length() <= 13 && recipient.length() >= 10) return 1;
        return 0;
    }

    public String checkRecipientCellMessage() {
        if (checkRecipientCell() == 1) return "Cell phone number successfully captured.";
        return "Cell phone number is incorrectly formatted or does not contain an international code.";
    }

    public String createMessageHash() {
        String firstTwo = messageID.substring(0,2);
        String[] words = messageText.trim().split("\\s+");
        String first = words[0].toUpperCase().replaceAll("[^A-Z0-9]", "");
        String last = words[words.length-1].toUpperCase().replaceAll("[^A-Z0-9]", "");
        return firstTwo + ":" + numSent + ":" + first + last;
    }

    public String checkMessageLength() {
        if (messageText.length() > 250) {
            int excess = messageText.length() - 250;
            return "Message exceeds 250 characters by " + excess + ", please reduce size.";
        }
        return "Message ready to send.";
    }

    public String SentMessage(int choice) {
        if (choice == 1) {
           this.flag = "Sent";
           sentMessages.add(this);
           allMessages.add(this);
           messageIDs.add(this.messageID);
           messageHashes.add(this.messageHash);
           totalMessagesSent++;
           return "Message successfully sent.";
    }
        if (choice == 2) {
           this.flag = "Disregard";
           disregardedMessages.add(this);
           allMessages.add(this);
           messageIDs.add(this.messageID);
           messageHashes.add(this.messageHash);
           return "Press 0 to delete message.";
    }
        if (choice == 3) {
           this.flag = "Stored";
           storedMessages.add(this);
           allMessages.add(this);
           messageIDs.add(this.messageID);
           messageHashes.add(this.messageHash);
           storeMessage();
           return "Message successfully stored.";
    }
    return "Invalid.";
    }

    public String printMessages() { return "Messages"; }
    public int returnTotalMessagess() { return totalMessagesSent; }

    public void storeMessage() {
           try {
        FileWriter w = new FileWriter("storedMessages.json");
        w.write("[\n");
        boolean first = true;
        for (Message m : storedMessages) {
            if (!first) w.write(",\n");
            first = false;
            w.write("  {\"sender\":\"" + m.sender + "\","
                + "\"recipient\":\"" + m.recipient + "\","
                + "\"message\":\"" + m.messageText.replace("\"", "\\\"") + "\","
                + "\"messageID\":\"" + m.messageID + "\","
                + "\"hash\":\"" + m.messageHash + "\"}");
        }
        w.write("\n]\n");
        w.close();
    } catch (IOException e) {
        System.out.println("Error: " + e.getMessage());
    }
    }

    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public String getSender() { return sender; }
    public String getFlag() { return flag; }
    public void setFlag(String flag) { this.flag = flag; }
    public void setSender(String sender) { this.sender = sender; }
    public static void clearAll() {
    sentMessages.clear(); disregardedMessages.clear(); storedMessages.clear();
    allMessages.clear(); messageHashes.clear(); messageIDs.clear();
    totalMessagesSent = 0;
    }

    public static void populateTestData() {
    clearAll();
    Message m1 = new Message("0838884567", 0, "+27834557896", "Did you get the cake?");
    m1.setFlag("Sent");
    sentMessages.add(m1); allMessages.add(m1);
    messageIDs.add(m1.getMessageID()); messageHashes.add(m1.getMessageHash());
    totalMessagesSent++;

    Message m2 = new Message("0838884567", 1, "+27838884567", "Where are you? You are late! I have asked you to be on time.");
    m2.setFlag("Stored");
    storedMessages.add(m2); allMessages.add(m2);
    messageIDs.add(m2.getMessageID()); messageHashes.add(m2.getMessageHash());

    Message m3 = new Message("0838884567", 2, "+27834484567", "Yohoooo, I am at your gate.");
    m3.setFlag("Disregard");
    disregardedMessages.add(m3); allMessages.add(m3);
    messageIDs.add(m3.getMessageID()); messageHashes.add(m3.getMessageHash());

    Message m4 = new Message("0838884567", 3, "0838884567", "It is dinner time!");
    m4.setFlag("Sent");
    sentMessages.add(m4); allMessages.add(m4);
    messageIDs.add(m4.getMessageID()); messageHashes.add(m4.getMessageHash());
    totalMessagesSent++;

    Message m5 = new Message("0838884567", 4, "+27838884567", "Ok, I am leaving without you.");
    m5.setFlag("Stored");
    storedMessages.add(m5); allMessages.add(m5);
    messageIDs.add(m5.getMessageID()); messageHashes.add(m5.getMessageHash());
    }
    public static String displaySenderAndRecipientOfStored() {
     StringBuilder sb = new StringBuilder();
     for (Message m : storedMessages) sb.append("Sender: ").append(m.sender).append(", Recipient: ").append(m.recipient).append("\n");
     return sb.toString().trim();
    }

     public static String displayLongestStoredMessage() {
        String longest = "";
           for (Message m : storedMessages) if (m.messageText.length() > longest.length()) longest = m.messageText;
     return longest;
    }

     public static String searchByMessageID(String id) {
       for (Message m : allMessages) if (m.messageID.equals(id)) return "Recipient: " + m.recipient + "\nMessage: " + m.messageText;
     return "Message ID not found.";
    }

     public static String searchMessageByIDReturnMessage(String id) {
       for (Message m : allMessages) if (m.messageID.equals(id)) return m.messageText;
     return "";
    }

    public static String searchByRecipient(String recipient) {
      StringBuilder sb = new StringBuilder();
        for (Message m : allMessages) if (m.recipient.equals(recipient)) {
          if (sb.length() > 0) sb.append("\n");
             sb.append(m.messageText);
    }
         return sb.length() == 0 ? "No messages found." : sb.toString();
   }

    public static String deleteByHash(String hash) {
       for (int i = 0; i < allMessages.size(); i++) {
        Message m = allMessages.get(i);
        if (m.messageHash.equalsIgnoreCase(hash)) {
            String deleted = m.messageText;
            sentMessages.remove(m); storedMessages.remove(m); disregardedMessages.remove(m);
            allMessages.remove(i); messageIDs.remove(m.messageID); messageHashes.remove(m.messageHash);
            return "Message: \"" + deleted + "\" successfully deleted.";
        }
    }
    return "Message hash not found.";
    }

     public static String displayReport() {
        StringBuilder sb = new StringBuilder("=== SENT MESSAGES REPORT ===\n");
         for (Message m : sentMessages) {
           sb.append("Message Hash: ").append(m.messageHash).append("\n")
            .append("Recipient: ").append(m.recipient).append("\n")
            .append("Message: ").append(m.messageText).append("\n\n");
       }
        return sb.toString().trim();
   }
    
}