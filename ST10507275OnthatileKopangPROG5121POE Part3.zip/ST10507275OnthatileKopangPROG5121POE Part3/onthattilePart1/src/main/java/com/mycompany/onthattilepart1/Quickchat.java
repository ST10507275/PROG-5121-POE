/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.onthattilepart1;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class Quickchat {
    public static void main(String[] args) {
        Scanner myInput = new Scanner(System.in);
        boolean isLoggedIn = true; // from Part 1 login

        if (!isLoggedIn) {
            System.out.println("Login required.");
            return;
        }

        System.out.println("Welcome to QuickChat.");
        System.out.print("How many messages do you wish to enter? ");
        int totalToSend = myInput.nextInt();
        myInput.nextLine();

        int sentCount = 0;
        boolean running = true;
        
        while (running) {
            System.out.println("\n1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4. Stored Messages");
            System.out.print("Choose: ");
            int menu = myInput.nextInt();
            myInput.nextLine();

            if (menu == 1) {
                System.out.print("Enter Recipient Cell (+27718693002): ");
                String rec = myInput.nextLine();
                System.out.print("Enter Message (max 250 chars): ");
                String txt = myInput.nextLine();

                if (txt.length() > 250) {
                    System.out.println("Message exceeds 250 characters by " + (txt.length()-250) + ", please reduce size.");
                    continue;
                }

                Message msg = new Message(sentCount, rec, txt);
                
                System.out.println(msg.checkRecipientCellMessage());
                if (msg.checkRecipientCell() == 0) continue;

                System.out.println("\n--- Full Message Details ---");
                System.out.println("MessageID: " + msg.getMessageID());
                System.out.println("MessageHash: " + msg.getMessageHash());
                System.out.println("Recipient: " + msg.getRecipient());
                System.out.println("Message: " + msg.getMessageText());

                System.out.print("\n1=Send 2=Disregard 3=Store: ");
                int choice = myInput.nextInt();
                myInput.nextLine();
                System.out.println(msg.SentMessage(choice));
                
                if (choice == 1) sentCount++;
                
            }   else if (menu == 2) {
                 System.out.println("\n--- Recently Sent Messages ---");
                  if (Message.sentMessages.isEmpty()) {
                   System.out.println("No messages sent yet.");
            }
                else {
                 for (Message m : Message.sentMessages) {
                 System.out.println("Recipient: " + m.getRecipient() + " | Message: " + m.getMessageText());
            }
         }
    } 
               else if (menu == 4) {
            // Part3 stored mssg menu
                System.out.println("\n--- Stored Messages ---");
                System.out.println("a. Display sender and recipient of all stored messages");
                System.out.println("b. Display longest stored message");
                System.out.println("c. Search by Message ID");
                System.out.println("d. Search messages for a recipient");
                System.out.println("e. Delete message by hash");
                System.out.println("f. Display full report");
                System.out.println("g. Back");
                System.out.print("Choose (a-g): ");
              String c = myInput.nextLine().toLowerCase();

    if (c.equals("a")) {
        System.out.println(Message.displaySenderAndRecipientOfStored());
    } else if (c.equals("b")) {
        System.out.println("Longest stored message: " + Message.displayLongestStoredMessage());
    } else if (c.equals("c")) {
        System.out.print("Enter Message ID: ");
        String id = myInput.nextLine();
        System.out.println(Message.searchByMessageID(id));
    } else if (c.equals("d")) {
        System.out.print("Enter recipient (+27...): ");
        String rec2 = myInput.nextLine();
        System.out.println(Message.searchByRecipient(rec2));
    } else if (c.equals("e")) {
        System.out.print("Enter Message Hash: ");
        String hash = myInput.nextLine();
        System.out.println(Message.deleteByHash(hash));
    } else if (c.equals("f")) {
        System.out.println(Message.displayReport());
    }
    } else if (menu == 3) {
       running = false;
    }
        }
        System.out.println("\nTotal messages sent: " + Message.totalMessagesSent);
        myInput.close();
    }
}
    

