/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.onthatilepart1;

import com.mycompany.onthattilepart1.Message;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class MessageJUnitTest {

    @Test
    public void testMessageLengthSuccess() {
        Message msg = new Message(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message ready to send.", msg.checkMessageLength());
    }

    @Test
    public void testMessageLengthFailure() {
        String longMsg = "A".repeat(260);
        Message msg = new Message(0, "+27718693002", longMsg);
        assertEquals("Message exceeds 250 characters by 10, please reduce size.", msg.checkMessageLength());
    }

    @Test
    public void testRecipientSuccess() {
        Message msg = new Message(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Cell phone number successfully captured.", msg.checkRecipientCellMessage());
        assertEquals(1, msg.checkRecipientCell());
    }

    @Test
    public void testRecipientFailure() {
        Message msg = new Message(0, "08575975889", "Hi Keegan, did you receive the payment?");
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code.", msg.checkRecipientCellMessage());
        assertEquals(0, msg.checkRecipientCell());
    }

    @Test
    public void testMessageHash() {
        // Using fixed ID 0012345678 to get 00:0:HITONIGHT as required in brief
        Message msg1 = new Message("0012345678", 0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("00:0:HITONIGHT", msg1.getMessageHash());
    }

    @Test
    public void testMessageID() {
        Message msg = new Message(0, "+27718693002", "Test");
        assertNotNull(msg.getMessageID());
        assertEquals(10, msg.getMessageID().length());
        System.out.println("Message ID generated: " + msg.getMessageID());
    }

    @Test
    public void testSendMessage() {
        Message msg = new Message(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message successfully sent.", msg.SentMessage(1));
    }

    @Test
    public void testDisregardMessage() {
        Message msg = new Message(0, "08575975889", "Hi Keegan, did you receive the payment?");
        assertEquals("Press 0 to delete message.", msg.SentMessage(2));
    }

    @Test
    public void testStoreMessage() {
        Message msg = new Message(0, "+27718693002", "Store this");
        assertEquals("Message successfully stored.", msg.SentMessage(3));
    }

    @Test
    public void testTotalMessages() {
        Message.sentMessages.clear();
        Message.totalMessagesSent = 0;
        Message msg1 = new Message(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        msg1.SentMessage(1);
        assertEquals(1, msg1.returnTotalMessagess());
        
        Message msg2 = new Message(1, "08575975889", "Hi Keegan, did you receive the payment?");
        msg2.SentMessage(2); // discard - should NOT increase total
        assertEquals(1, msg2.returnTotalMessagess());
    }
        @Test
    public void testPopulateTestData() {
        Message.populateTestData();
        assertEquals(5, Message.allMessages.size());
        assertEquals(2, Message.storedMessages.size());
        assertEquals(2, Message.sentMessages.size());
        assertEquals(1, Message.disregardedMessages.size());
    }

    @Test
    public void testDisplaySenderAndRecipientOfStored() {
        Message.populateTestData();
        String result = Message.displaySenderAndRecipientOfStored();
        assertTrue(result.contains("+27838884567"));
        assertTrue(result.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testDisplayLongestStoredMessage() {
        Message.populateTestData();
        assertEquals("Where are you? You are late! I have asked you to be on time.", Message.displayLongestStoredMessage());
    }

    @Test
    public void testSearchByMessageID() {
        Message.populateTestData();
        String id = Message.allMessages.get(0).getMessageID();
        String result = Message.searchByMessageID(id);
        assertTrue(result.contains("Did you get the cake?"));
    }

    @Test
    public void testSearchByRecipient() {
        Message.populateTestData();
        String result = Message.searchByRecipient("+27838884567");
        assertTrue(result.contains("Where are you? You are late!"));
        assertTrue(result.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testDeleteByHash() {
        Message.populateTestData();
        String hash = Message.allMessages.get(0).getMessageHash();
        String result = Message.deleteByHash(hash);
        assertTrue(result.toLowerCase().contains("deleted"));
        assertEquals(4, Message.allMessages.size());
    }

    @Test
    public void testDisplayReport() {
        Message.populateTestData();
        String report = Message.displayReport();
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains("It is dinner time!"));
    }
}